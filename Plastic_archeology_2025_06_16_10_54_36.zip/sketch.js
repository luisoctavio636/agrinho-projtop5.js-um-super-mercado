let itens = [];
let carrinho = [];
let totalCompra = 0;

// Classe para representar um item no mercado
class Item {
    constructor(x, y, largura, altura, nome, preco, cor) {
        this.x = x;
        this.y = y;
        this.largura = largura;
        this.altura = altura;
        this.nome = nome;
        this.preco = preco;
        this.cor = cor;
        this.comprado = false; // Indica se o item foi clicado
    }

    // Desenha o item na tela
    display() {
        if (!this.comprado) {
            fill(this.cor);
            rect(this.x, this.y, this.largura, this.altura);
            fill(0); // Cor do texto preta
            textAlign(CENTER, CENTER);
            textSize(12);
            text(this.nome, this.x + this.largura / 2, this.y + this.altura / 2 - 5);
            textSize(10);
            text(`R$ ${this.preco.toFixed(2)}`, this.x + this.largura / 2, this.y + this.altura / 2 + 10);
        }
    }

    // Verifica se o mouse está sobre o item
    contem(px, py) {
        return px > this.x && px < this.x + this.largura && py > this.y && py < this.y + this.altura;
    }
}

function setup() {
    createCanvas(800, 600);
    // Cria alguns itens para o mercado
    itens.push(new Item(100, 150, 60, 60, "Maçã", 2.50, [255, 100, 100]));
    itens.push(new Item(200, 150, 60, 60, "Pão", 5.00, [200, 150, 100]));
    itens.push(new Item(300, 150, 60, 60, "Leite", 7.20, [220, 220, 220]));
    itens.push(new Item(100, 250, 60, 60, "Cenoura", 3.00, [255, 165, 0]));
    itens.push(new Item(200, 250, 60, 60, "Brócolis", 4.50, [100, 150, 50]));
    itens.push(new Item(300, 250, 60, 60, "Suco", 6.80, [150, 200, 255]));
}

function draw() {
    background(180, 230, 255); // Cor de fundo que simula o céu ou uma parede clara

    // Desenha o chão/balcão do mercado
    fill(150, 100, 50);
    rect(0, height - 100, width, 100);

    // Desenha as prateleiras (simples)
    fill(120, 80, 40);
    rect(80, 120, 280, 160); // Prateleira 1
    rect(80, 220, 280, 160); // Prateleira 2

    // Desenha todos os itens disponíveis
    for (let item of itens) {
        item.display();
    }

    // Desenha o carrinho de compras
    fill(200);
    rect(width - 150, 50, 120, height - 100);
    fill(0);
    textSize(16);
    textAlign(CENTER, TOP);
    text("Meu Carrinho", width - 90, 60);

    // Exibe os itens no carrinho
    let yCarrinho = 90;
    for (let item of carrinho) {
        fill(0);
        textAlign(LEFT, TOP);
        textSize(12);
        text(`<span class="math-inline">\{item\.nome\} \- R</span> ${item.preco.toFixed(2)}`, width'  

  
